About the Latin Library
=======================

The Latin Library is a collection of a wide variety of texts from the archaic period to the modern era. Altogether the corpus is about 108 MB.

These files are in the public domain, [as explained here](http://thelatinlibrary.com/about.html). For a declaration of these files' status in public domain, see LICENSE.md.
